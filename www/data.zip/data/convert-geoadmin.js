const fs = require('fs');
const iconvlite = require('iconv-lite');
const parse = require('csv-parse');

const file = './nucleaire-2016-municipalities.csv';

function readFileSync_encoding(filename, encoding) {
    var content = fs.readFileSync(filename);
    return iconvlite.decode(content, encoding);
}

let input = readFileSync_encoding(file, 'utf8');
parse(input, {delimiter: ";"}, function(err, output){
  let o = {};
  output.forEach(c => {
    o[parseInt(c[0], 10)] = {
      id: parseInt(c[0], 10),
      name: c[1].replace(/^[^A-Z]+/, ''),
      p: c[2],
      v: parseFloat(c[4].replace(',', '.'))
    };
  });

  fs.writeFileSync(file.replace('.csv', '.json'), JSON.stringify(o));
});
